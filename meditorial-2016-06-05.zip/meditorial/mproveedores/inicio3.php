<html>
<head>
<title>Base de datos</title>
<link rel="stylesheet" type="text/css" href="estilo.css">
</head>

<body background="f.png" style="background-attachment: fixed">
<div class="arriba">
<h1 align="center"><u> <font color="white" face="Lubalin Graph">Proveedores</font> </u></h1>
</div> 

<div class="fondo2" align="center">
<img src="m.png" width="250" height="90" vspace="20px">
<img src="logo solo.jpg" width="180" height="200" vspace="50px">


</div>

<div class="medio" align="center">
<ul>
<br>
<p><a href='ingresaprov.php'><input class="button" type="button" value="A�adir Proveedor"></a></p>
<br>
<p><a href='modprov.php'><input class="button" type="button" value="Modificar Proveedor"></a></p>
<br>
<a href='../inicio.php'><input class="button" type="button" value="Volver a inicio"></a>
</ul>

</div>

<div class="arriba">
<h1 align="center"><font color="white" face="Lubalin Graph">ORIENTACI&Oacute;N para el FUTURO</font></h1>
</div>


</body>
</html>