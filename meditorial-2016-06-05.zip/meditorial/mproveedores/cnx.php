<?php

$cnx = mysql_pconnect('localhost', 'root', '') or die('Error en la conexion');
$db = mysql_select_db('meditorial');



?>