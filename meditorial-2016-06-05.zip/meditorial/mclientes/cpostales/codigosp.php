<html>
<head>
<title></title>

</head>
<body>
<form action="agregacp.php" method="POST">
     <table border="2">
	 <tr>
	<td><font face="tahoma" size="4">Codigo Postal:</font></td> 
	<td colspan="10"><input  type="text" id="codigos" name="codigos" /></td>
	</tr>
	<tr>
	<td><font face="tahoma" size="4">Localidad:</font></td>
	<td colspan="10"><input type="text" id="descripcion" name="descripcion" /></td>
	</tr>
	
	  </table>
	<input class="button" type="submit" value="ENVIAR"/>
	

</form>






</body>
</html>