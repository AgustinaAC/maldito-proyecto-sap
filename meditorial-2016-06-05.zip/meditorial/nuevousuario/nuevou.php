<html>
<head>
<title></title>
<meta name="" content="">
<link rel="stylesheet" type="text/css" href="estilo.css">
 
</head>
<body background="f.png" style="background-attachment: fixed">

<div class="arriba">
<h1 align="center"><i><u><font color="white" face="Lubalin Graph">Cliente</font> </u></i></h1>
</div> 

<div class="fondo2" align="center">
<img src="me.png" width="300" height="90" vspace="30px">

<img src="logo solo.jpg" width="180" height="200" vspace="50px">
</div>

<div class="medio" align="center">
 <form action="agreganu.php" method="post">
<br>
<br>
<br>
     <table border="2">
	 <tr>
	<td><font face="tahoma" size="4">Nuevo Usuario:</font></td> 
	<td colspan="10"><input  type="text" name="nu" size="45"/></td>
	</tr>
	<tr>
	<td><font face="tahoma" size="4">Nueva Clave:</font></td>
	<td colspan="10"><input type="text" name="nc" size="45"/></td>
	</tr>
	
	  <tr>
	<td><input class="button" type="submit" value="ENVIAR"/></td>
	</tr>
</table>

</form>

</div>

<div class="arriba">
<h1 align="center"><font color="white" face="Lubalin Graph">ORIENTACI&Oacute;N para el FUTURO</font></h1>
</div>


</body>
</html>