<link rel="stylesheet" type="text/css" href="estilo.css">
<?php

$nom2=$_POST["hh"];
$conec=mysql_connect("localhost","root",""); //conexi�n con el servidor
if(!$conec){
    echo "<h1>La conexi�n no se realiz� con �xito</h1>";
    exit();
}else{
   mysql_select_db("meditorial"); //conecta con la base de datos
	$result=mysql_query("select * from productos where codp like '$nom2'");
	
	if(mysql_fetch_array($result)){
		mysql_query("delete from productos where codp='$nom2' "); // borra el registro completo que coincida con la condici�n
		echo "<h1>el registro ha sido borrado</h1>";
	}else{
		echo "<h1>Los datos no se encontraron</h1>";
	}
   }
mysql_close ($conec);
?>
<a href="inicio.html"><input class="button2" type="button" value="volver"/>
