<html>
<form method='POST' action='index2.php'>
Usuario <input type='text' name='usuario'/><br/>
Password <input type='password' name='clave'/><br/>
<input type='submit' value='Ingresar'/>
</form>
</html>