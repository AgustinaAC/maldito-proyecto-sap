<html>
<head>
<link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body background="f.png" style="background-attachment:fixed">

<div>
<img src="me.png" width="900" height="200" hspace="300px">
</div>

<div class="medio" align="center">
<h2><p align="center"> Si olvidaste la clave o tu usuario, tienes dos opciones.<br>
1- LLama al numero 0341-153-186220.<br>
2- copia este e-mail <span style="color: blue;"> gabrielzrm@hotmail.com </span> envianos un correo con tu numero telefonico sera contestado en la brevedad.<br>
Elige  en los siguientes iconos tu proveedor de correo electronico:<br></h2>

<a href='https://login.live.com/login.srf?wa=wsignin1.0&ct=1384918821&rver=6.1.6206.0&sa=1&ntprob=-1&wp=MBI_SSL_SHARED&wreply=https:%2F%2Fmail.live.com%2F%3Fowa%3D1%26owasuffix%3Dowa%252f&id=64855&snsc=1&cbcxt=mail'><img src="outlook.jpg" width="150" height="150" hspace="30px"></a>  
<a href='https://accounts.google.com/ServiceLogin?service=mail&passive=true&rm=false&continue=https://mail.google.com/mail/&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1'><img src="gmail.jpg" width="150" height="150" hspace="30px"></a>  
<br></p>

</div>


</body>
</html>